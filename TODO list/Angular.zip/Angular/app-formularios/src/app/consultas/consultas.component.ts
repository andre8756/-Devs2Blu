import { Component } from '@angular/core';

@Component({
  selector: 'app-consultas',
  imports: [],
  templateUrl: './consultas.component.html',
  styleUrl: './consultas.component.css'
})
export class ConsultasComponent {

}
