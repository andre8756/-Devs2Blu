import { Component } from '@angular/core';

@Component({
  selector: 'app-page-erro',
  imports: [],
  templateUrl: './page-erro.component.html',
  styleUrl: './page-erro.component.css'
})
export class PageErroComponent {

}
