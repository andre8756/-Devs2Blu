import { Component } from '@angular/core';

@Component({
  selector: 'app-consulta',
  imports: [],
  templateUrl: './consulta.component.html',
  styleUrl: './consulta.component.css'
})
export class ConsultaComponent {

}
