import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ContatoService {
  private apiUrl = 'http://localhost:3000/contatos'
  constructor(private client: HttpClient) { }

  getContatos(): Observable<any>{
    return this.client.get<any[]>(this.apiUrl);  //dando um get no client --get<any[]> representa o que ele retorna, no caso, uma lista de qualquer coisa
  }

  save(contato:any):Observable<any>{
    console.log(contato)
    return this.client.post<any>(this.apiUrl,contato);
  }

  update(contato:any):Observable<any>{
    const url = `${this.apiUrl}/${contato.id}`;  // Assume que cada contato tem um 'id'
    return this.client.put<any>(url, contato);
  }

  delete(contatoId: number): Observable<any> {
    const url = `${this.apiUrl}/${contatoId}`;
    return this.client.delete<any>(url);
  }

}
